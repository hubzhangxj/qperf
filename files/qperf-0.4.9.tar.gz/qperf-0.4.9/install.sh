build_scimark() {
    set -e
    ARCH=`uname -i`
    SrcPath=/tmp/qperf-0.4.9
    BuildPATH="/tmp/build.qperf"
    mkdir -p $BuildPATH
    if [ $ARCH = "aarch64" -o $ARCH = "aarch32" ]
    then
        cd $BuildPATH
        export ac_cv_func_malloc_0_nonnull=yes
        $SrcPath/configure --disable-shared --enable-static --prefix=$BuildPATH
        make
    else
        cd $BuildPATH
        $SrcPath/configure --prefix=$BuildPATH
        make
    fi
}

build_scimark
